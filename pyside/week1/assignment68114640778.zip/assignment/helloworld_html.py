import sys
from PySide6.QtWidgets import *

app = QApplication(sys.argv)
# make label
label_native = QLabel("<font color=red size=40>Hello World</font>")
label_native.show()
# Enter Qt app main loop
app.exec()
app.exit()