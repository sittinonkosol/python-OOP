import sys
from PySide6.QtWidgets import *
app = QApplication(sys.argv)
win = QWidget()
win.resize(320, 240)
win.setWindowTitle("Hello, World!") 
layout = QVBoxLayout() 
win.setLayout(layout) 
label = QLabel("Hello World") 
layout.addWidget(label)
win.show()
app.exec()
sys.exit()