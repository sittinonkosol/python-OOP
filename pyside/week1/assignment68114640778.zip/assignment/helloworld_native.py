import sys
from PySide6.QtWidgets import *

app = QApplication(sys.argv)
# make label
label_native = QLabel("Hello World")
label_native.show()
# Enter Qt app main loop
app.exec()
app.exit()