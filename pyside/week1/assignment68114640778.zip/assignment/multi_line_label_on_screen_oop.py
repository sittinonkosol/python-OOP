import sys
from PySide6.QtWidgets import *

class myApp(QWidget):
    def __init__(self):
        super().__init__()
        self.resize(300,240)
        self.setWindowTitle("Hello, World!")
        layout = QVBoxLayout()
        self.setLayout(layout)

        label1 = QLabel("Hello, World!")
        label2 = QLabel("Hello, World!")
        label3 = QLabel("Hello, World!")

        layout.addWidget(label1)
        layout.addWidget(label2)
        layout.addWidget(label3)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = myApp()
    win.show()
    sys.exit(app.exec())