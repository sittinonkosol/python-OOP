import sys
from PySide6.QtWidgets import *
app = QApplication(sys.argv)
win = QWidget()
win.resize(320, 240) 
win.setWindowTitle("Hello, World!")
win.show()
app.exec()
sys.exit()